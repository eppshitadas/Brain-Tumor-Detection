# Dataset

No dataset is committed to this repository (see the top-level `.gitignore` and
`13. GitHub` requirement). Download one of the following free, public Kaggle
datasets and place it inside this `dataset/` folder before running
`training/train_model.py`.

## Option A - "Brain MRI Images for Brain Tumor Detection" (binary, simplest)
https://www.kaggle.com/datasets/navoneel/brain-mri-images-for-brain-tumor-detection

Unzip so you end up with:
```
dataset/
├── yes/    (tumor images)
└── no/     (no-tumor images)
```

## Option B - "Brain Tumor MRI Dataset" (4-class, larger)
https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset

Unzip so you end up with:
```
dataset/
├── glioma/
├── meningioma/
├── pituitary/
└── notumor/
```
`train_model.py` automatically treats `notumor` as the negative class and
merges `glioma`, `meningioma` and `pituitary` into a single positive
("tumor") class, since the app is a binary detector, not a 4-class
classifier.

## Downloading with the Kaggle CLI
```bash
pip install kaggle
# place your kaggle.json API token in ~/.kaggle/ first (see Kaggle's account settings)
kaggle datasets download -d navoneel/brain-mri-images-for-brain-tumor-detection -p dataset --unzip
```

## Using your own dataset
Any folder tree works as long as each image's *parent folder name* is one of:
- negative: `no`, `no_tumor`, `notumor`
- positive: `yes`, `tumor`, `glioma`, `meningioma`, `pituitary`

Supported formats: JPG, PNG, BMP. Corrupted or unreadable files are skipped
automatically and reported in the training log.
