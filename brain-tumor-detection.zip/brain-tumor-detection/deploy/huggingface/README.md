# Deploying the backend on Hugging Face Spaces (Docker)

TensorFlow makes the backend too large for most free serverless hosts (their
zipped-function size limits are usually 250 MB, and the TensorFlow wheel
alone is over that). A small always-on Docker container is the reliable free
option. Hugging Face Spaces (Docker SDK) or Render (Docker) both work; steps
below are for Hugging Face, Render is nearly identical.

## Steps
1. Create a free account at https://huggingface.co and click **New Space**.
2. Choose **Docker** as the Space SDK, any name, "Public" visibility.
3. In the new Space's **Files** tab, upload the contents of `backend/`,
   `model/` and this `Dockerfile` (copy it to the Space's root - see below).
4. In the Space's **Settings -> Variables and secrets**, add:
   - `CORS_ORIGINS` = the URL of your deployed Vercel frontend
     (e.g. `https://brain-tumor-detection.vercel.app`)
5. The Space rebuilds automatically and gives you a URL such as
   `https://<username>-<space-name>.hf.space`. Use that as `VITE_API_URL`
   in the frontend (see the top-level README's Deployment section).

If your trained `model/brain_tumor_model.keras` is larger than 10 MB, do not
commit it to git or the Space repo directly - instead upload it as a file in
the Space (drag-and-drop in the Files tab works up to a few hundred MB) or
host it anywhere with a direct HTTPS download link and set the `MODEL_URL`
environment variable instead; `backend/predict.py` downloads it
automatically on first request.
